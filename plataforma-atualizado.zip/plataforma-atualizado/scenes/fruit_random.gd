extends Node2D

signal fruit_collected

@export var types_fruit: Array[SpriteFrames]

@onready var animated_sprite_2d: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	var choice = types_fruit.pick_random()
	animated_sprite_2d.sprite_frames = choice
	animated_sprite_2d.play("default")
	pass

func _on_area_2d_area_entered(area: Area2D) -> void:
	print("Pegou uma Fruta")
	fruit_collected.emit()
	queue_free() # Remove este nó do jogo
