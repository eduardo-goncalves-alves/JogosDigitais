extends Node2D

var points = 0
var spawn_position: Vector2 # Guarda onde o player ira renascer

@onready var hud: CanvasLayer = $HUD
@onready var mark_die: Marker2D = $MarkDie
@onready var player: CharacterBody2D = $Player 

func _ready():
	spawn_position = player.global_position
	
	var all_fruits = get_tree().get_nodes_in_group("g_fruits")
	for fruit in all_fruits:
		fruit.fruit_collected.connect(_on_fruit_collected)
	
	var all_damages = get_tree().get_nodes_in_group("g_damages")
	for damage in all_damages:
		damage.damaged.connect(_on_damaged)
		
	var all_checkpoints = get_tree().get_nodes_in_group("g_checkpoints")
	for checkpoint in all_checkpoints:
		checkpoint.checkpoint_reached.connect(_on_checkpoint_reached)
	
func _process(delta: float) -> void:
	if player.global_position.y > mark_die.global_position.y:
		_on_damaged()
	
func _on_fruit_collected():
	points += 1
	hud.eat_fruit()
	
func _on_damaged():
	print("Morreu")
	# retorna o plauer para o último ponto
	player.global_position = spawn_position
	
func _on_checkpoint_reached(new_pos: Vector2):
	spawn_position = new_pos
