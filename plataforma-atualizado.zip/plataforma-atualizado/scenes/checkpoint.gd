extends Node2D

signal checkpoint_reached(pos)

func _on_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		print("Checkpoint salvo")

		checkpoint_reached.emit(global_position)
