extends CharacterBody2D

var speed = 300
var gravity = 980
var jump_velocity = -400

var can_double_jump = false 

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

func _ready():
	pass

func _process(delta: float):
	if not is_on_floor():
		velocity.y += gravity * delta
	else:
		can_double_jump = true 
		
	var direction = Input.get_axis("move_left", "move_right")
	velocity.x = direction * speed
	
	if Input.is_action_just_pressed("jump"):
		if is_on_floor():
			velocity.y = jump_velocity
		elif can_double_jump:
			velocity.y = jump_velocity
			can_double_jump = false 

	move_and_slide()
	
	if is_on_floor():
		if velocity.x == 0:
			anim.play("idle")
		else:
			anim.play("walk")
	else:
		if velocity.y < 0:
			anim.play("jump")
		else:
			anim.play("fall")
			
	if direction < 0:
		anim.flip_h = true
	elif direction > 0:
		anim.flip_h = false
