extends Area2D

# Você pode arrastar a sua Cena da Fase 2 do FileSystem direto pro Inspetor com isso!
@export var next_level: PackedScene 

func _on_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		if next_level:
			get_tree().change_scene_to_packed(next_level)
