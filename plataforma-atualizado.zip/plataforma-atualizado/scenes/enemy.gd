extends CharacterBody2D

signal damaged 

var speed = 100.0
var direction = -1
var gravity = 980.0

@onready var anim = $AnimatedSprite2D

func _physics_process(delta):

	if not is_on_floor():
		velocity.y += gravity * delta

	# Se o inimigo bater em uma parede, a direção será invertida
	if is_on_wall():
		direction *= -1 
		anim.flip_h = not anim.flip_h
	velocity.x = direction * speed
	
	# Mude "walk" para o nome que você deu na sua animação!
	anim.play("default") 
	
	move_and_slide()	

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body.name == "Player":
		print("Inimigo bateu no player! Causando dano...")
		damaged.emit()
